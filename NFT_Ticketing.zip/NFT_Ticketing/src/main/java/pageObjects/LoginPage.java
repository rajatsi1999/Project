package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage
{
public WebDriver driver;

    By login = By.xpath("//input[@placeholder='Email Address']");
    By password = By.xpath("//input[@placeholder='Password']");
    By checkbox = By.xpath("//input[@type='checkbox']");
    By submitbutton = By.xpath("/html/body/div[1]/div/div/button");
    
    public LoginPage(WebDriver driver) 
    {
		// TODO Auto-generated constructor stub
    	this.driver=driver;
	}

	public WebElement getlogin()
    {
    return driver.findElement(login); 
    }
	
	public WebElement getPassword()
	{
		return driver.findElement(password);
		
	}
	public WebElement getcheckbox()
	{
		return driver.findElement(checkbox);
		
	}
	public WebElement getsubmitbutton()
	{
		return driver.findElement(submitbutton);
		
	}
}
