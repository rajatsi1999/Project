package Automation.Full_Scortik;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObjects.Dashboard;
import pageObjects.LoginPage;
import resources.base;

public class ValidLogin extends base 
{
	@Test(dataProvider="getData")
public void validlogin(String Username, String Password, String text) throws IOException
{
	driver = InitializeDriver();
	driver.get(prop.getProperty("url"));
	//invoking method of class - LoginPage.java
	LoginPage l= new LoginPage(driver);
	Dashboard d=new Dashboard(driver);
	l.getlogin().click();
	l.getlogin().sendKeys(Username);
	l.getPassword().sendKeys(Password);
	l.getcheckbox().click();
	l.getsubmitbutton().click();
	
	
	assert.assertEquals(,"Dashboard");
	
} 
	//public void invalidlogin() throws IOException
	//{
	//	driver = InitializeDriver();
	//	driver.get("http://nftticketing-dev-1099243859.us-east-1.elb.amazonaws.com/");
		//invoking method of class - LoginPage.java
	//	LoginPage l= new LoginPage(driver);
	//	l.getlogin().click();
	//	l.getlogin().sendKeys("akashku+41@leewayhertz.com");
	//	l.getPassword().sendKeys("Admin@123");
	//	l.getcheckbox().click();
	//	l.getsubmitbutton().click();
	//	System.out.println(text);
	//}

	
	@DataProvider
	public Object[][] getData()
	{
		//row for how many data dtyepe test should run
		//column=values per each test
		Object data[][]= new Object[1][3];
		data[0][0]="akashku+41@leewayhertz.com";
		data[0][1]="Admin@123";
		data[0][2]="Valid User";
		
		//data[1][0]="akash";
	//	data[1][1]="Admin";
		//data[1][2]="InValid User";
		
		//data[2][0]="Rajat";
		//data[2][1]="kdmkjcbdvcbdsvbdscbkdsjbvkjdsbvkjdsbvkjdsbvkjdsbkjvdskj";
		//data[2][2]="InValid User";
		return data;
		
	}
	
	@AfterTest
	public void closebrowser()
	{
		driver.close();
	}

}
