package Automation.Full_Scortik;

import java.io.IOException;

import org.testng.annotations.Test;


import pageObjects.LoginPage;
import resources.base;

public class InvalidLogin extends base
{
	@Test

	public void invalidlogin() throws IOException
	{
		driver = InitializeDriver();
		driver.get(prop.getProperty("url"));
		//invoking method of class - LoginPage.java
		LoginPage l= new LoginPage(driver);
		l.getlogin().click();
		l.getlogin().sendKeys("a");
		l.getPassword().sendKeys("Admin");
		l.getcheckbox().click();
		l.getsubmitbutton().click();
		System.out.println("Invalid Login");
	}
	public void closebrowser()
	{
		driver.close();
	}

}
