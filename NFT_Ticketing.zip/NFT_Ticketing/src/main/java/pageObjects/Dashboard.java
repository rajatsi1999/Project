package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Dashboard 
{
	public WebDriver driver;

    By dashboard = By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div/div[1]");
  
    
    public Dashboard(WebDriver driver) 
    {
		// TODO Auto-generated constructor stub
    	this.driver=driver;
	}

	public WebElement getdashboard()
    {
    return driver.findElement(dashboard); 
    }
}
